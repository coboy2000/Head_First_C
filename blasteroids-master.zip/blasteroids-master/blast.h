#pragma once

#include "object.h"

void blast_draw(Object* o);
void blast_define(Object* o, Euclidean start);
