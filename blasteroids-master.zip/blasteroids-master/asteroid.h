#pragma once

#include "object.h"

void asteroid_draw(Object* o);
void asteroid_define(Object* o, Euclidean resolution);
