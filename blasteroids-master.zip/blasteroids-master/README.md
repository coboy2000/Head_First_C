# blasteroids

This is a simple clone of the game Asteroids, inspired by the book [*Head First C*](http://www.amazon.com/Head-First-C-David-Griffiths/dp/1449399916).

This game uses [Allegro 5](http://alleg.sourceforge.net/) libraries.