#pragma once

#include "object.h"

void spaceship_draw(Object* o);
void spaceship_define(Object* o, Euclidean resolution);
